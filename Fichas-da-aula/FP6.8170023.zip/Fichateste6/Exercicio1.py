lista = []

for i in range(1,21):
    lista.append(i)
print("Lista: ",lista)